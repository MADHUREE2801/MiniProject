const ball = document.querySelector('.ball')
const container = document.querySelector('.midDiv')

ball.addEventListener('click', function () {
    ball.classList.toggle('ball-toggle')
});